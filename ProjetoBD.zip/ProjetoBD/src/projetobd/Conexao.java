package projetobd;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Conexao {

    public static Connection abrirConexao() {

        Connection con = null;

        try {
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        } catch (ClassNotFoundException ex) {
            System.out.println(ex);
        } catch (InstantiationException ex) {
            System.out.println(ex);
        } catch (IllegalAccessException ex) {
            System.out.println(ex);
        }

        String url;

        url = "";

        url += ("jdbc:mysql://127.0.0.1/estacionamento?");

        url += "user=root&&password=";

        try {
            con = DriverManager.getConnection(url);
            System.out.println("conexao aberta!!!");

        } catch (SQLException ex) {
            System.out.println(ex);
        } catch (Exception e) {
            System.out.println(e);
        }

        return con;
    }

    public static void fecharconexao(Connection con) {
        try {

            con.close();
        } catch (SQLException e) {

        }
        System.out.println("Conexão fechada.");

    }
}
